#!/usr/bin/python
import hashlib
import rpclib
import sys
import os
import sandboxlib
import urllib
import socket
import bank_client
import zoodb
from visitor_client import *
import visitor_client
from debug import *
from zoodb import *
## Cache packages that the sandboxed code might want to import
import time
import errno

class ProfileAPIServer(rpclib.RpcServer):
    def __init__(self, user, visitor):
        uid = 61014
        self.user = user
        self.visitor = visitor
        os.setresuid(uid,uid,uid)
    def rpc_get_self(self):
        return self.user

    def rpc_get_visitor(self):
        visitor_client.put_visitorlog(self.user, self.visitor)
        return self.visitor

    def rpc_get_xfers(self, username):
        xfers = []
        for xfer in bank_client.getlog(username):
            xfers.append({ 'sender': xfer['sender'],
                           'recipient': xfer['recipient'],
                           'amount': xfer['amount'],
                           'time': xfer['time']
                         })
        return xfers

    def rpc_get_user_info(self, username):
        person_db = zoodb.person_setup()
        p = person_db.query(zoodb.Person).get(username)
        if not p:
            return None
        return { 'username': p.username,
                 'profile': p.profile,
                 'zoobars': bank_client.balance(username)
               }

    def rpc_xfer(self, target, zoobars):
        bank_client.transfer(self.user, target, zoobars)
    def rpc_get_visitorlog(self):
        return visitor_client.get_visitorlog(self.user)

def run_profile(pcode, profile_api_client):
    globals = {'api': profile_api_client}
    exec pcode in globals

class ProfileServer(rpclib.RpcServer):
    def rpc_run(self, pcode, user, visitor):
        uid = 61014

        userdir = '/tmp/' + str(hashlib.sha512(user).hexdigest())[0:10]

        if not os.path.exists(userdir):
            print "is making dir\n"
            os.mkdir(userdir)
            print os.path.exists(userdir)
            print "\n"
            os.chmod(userdir, 0755)
            os.chown(userdir,uid,uid)
        print "anyway\n"
        (sa, sb) = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM, 0)
        pid = os.fork()
        if pid == 0:
            if os.fork() <= 0:
                sa.close()
                ProfileAPIServer(user, visitor).run_sock(sb)
                sys.exit(0)
            else:
                sys.exit(0)
        sb.close()
        os.waitpid(pid, 0)

        sandbox = sandboxlib.Sandbox(userdir, uid, '/profilesvc/lockfile')
        with rpclib.RpcClient(sa) as profile_api_client:
            return sandbox.run(lambda: run_profile(pcode, profile_api_client))


(_, dummy_zookld_fd, sockpath) = sys.argv
print "now in profile-server.py\n"
s = ProfileServer()
print "sockpath:%s\n"%sockpath
s.run_sockpath_fork(sockpath)
