from debug import *
import rpclib

def get_visitorlog(username):
    with rpclib.client_connect('/visitorsvc/sock') as c:
        kwargs = {'username':username}
        return c.call('getvisitorlog',**kwargs)
def put_visitorlog(username, visitorname):
    with rpclib.client_connect('/visitorsvc/sock') as c:
        kwargs = {'username':username,
                'visitorname':visitorname}
        return c.call('putvisitorlog',**kwargs)
