#!/usr/bin/python

import rpclib
import sys
import visitor
from debug import *

class VisitorRpcServer(rpclib.RpcServer):
    def rpc_getvisitorlog(self, username):
        return visitor.get_visitorlog(username)
    def rpc_putvisitorlog(self,username, visitorname):
        return visitor.put_visitorlog(username, visitorname)
(_, dummy_zookld_fd, sockpath) = sys.argv

s = VisitorRpcServer()
s.run_sockpath_fork(sockpath)
