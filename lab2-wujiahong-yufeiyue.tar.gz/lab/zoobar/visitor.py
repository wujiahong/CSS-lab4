from zoodb import *
from debug import *
import time
def format_result(temp):
    return {
        'username':temp.username,
        'visitorname':temp.visitorname,
        'time':temp.time
        }

def get_visitorlog(username):
    visitordb = visitor_setup()
    result = visitordb.query(Visitor).filter(Visitor.username==username)
    return [format_result(temp) for temp in result]

def put_visitorlog(username, visitorname ):
    visitordb = visitor_setup()
    newitem = Visitor()
    newitem.username = username
    newitem.visitorname = visitorname
    newitem.time = time.asctime()
    visitordb.add(newitem)
    visitordb.commit()
