from flask import g, render_template, request
from login import requirelogin
from debug import *
import zoodb
from zoodb import person_setup
from zoodb import *
@catch_err
@requirelogin
def index():
    if 'profile_update' in request.form:
        g.user.person.profile = request.form['profile_update']
        persondb = person_setup()
        person = persondb.query(Person).get(g.user.person.username)
        person.profile = g.user.person.profile
        persondb.commit()
    return render_template('index.html')
