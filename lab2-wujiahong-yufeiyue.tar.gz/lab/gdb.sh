#!/bin/sh

ulimit -s unlimited
gdb $@